/* Seciltek — Regras de materiais e chaves de catálogo
   Adicionar um sistema novo: criar as constantes e adicionar a chave a materialRules. */

/* ============================================================
   MICROART
   ============================================================ */
export const PRODUCT_KEYS = {
  MICRO_AD21_5:        "MICRO_ART_AD_21_BALDE_5_LT_MACEIRA",
  MICRO_REDE90:        "MICRO_ART_REDE_90_50_M2_1_ROLO_MACEIRA",
  MICRO_MC01_BASE_12:  "MICRO_ART_MC_01_BASE_BALDE_12_KG_MACEIRA",
  MICRO_MC01_BASE_3:   "MICRO_ART_MC_01_BASE_BALDE_3_KG_MACEIRA",
  MICRO_MC01_CORES_12: "MICRO_ART_MC_01_CORES_DE_CATALOGO_BALDE_12_KG_MACEIRA",
  MICRO_MC01_CORES_3:  "MICRO_ART_MC_01_CORES_DE_CATALOGO_BALDE_3_KG_MACEIRA",
  MICRO_MC02_CORES_12: "MICRO_ART_MC_02_CORES_DE_CATALOGO_BALDE_12_KG_MACEIRA",
  MICRO_MC02_CORES_3:  "MICRO_ART_MC_02_CORES_DE_CATALOGO_BALDE_3_KG_MACEIRA",
  MICRO_AD50_55:       "MICRO_ART_AD_50_BALDE_5_5_LT_MACEIRA",
  MICRO_AD92_5:        "MICRO_ART_AD_92_BALDE_5_LT_MACEIRA",
  MICRO_AD92_1:        "MICRO_ART_AD_92_BALDE_1_LT_MACEIRA",
  ISODUR_ONE:          "ISODUR_ONE_SACO_38_LT_MONTIJO_PATAIAS",
  ISODUR_PK_FLEX:      "ISODUR_PK_FLEX_SACO_25_KG_MONTIJO_RIO_MAIOR_PATAIAS",
  ISOVIT_EASYPRO:      "ISOVIT_EASYPRO_NOVO_SACO_25_KG_MONTIJO_RIO_MAIOR_PATAIAS",
  ISOVIT_FIBRAFLEX:    "ISOVIT_FIBRAFLEX_SACO_25_KG_MONTIJO_RIO_MAIOR_PATAIAS",
  ISOVIT_LIGHTFLEX:    "ISOVIT_LIGHTFLEX_SACO_20_KG_MONTIJO_PATAIAS",
  ISOVIT_AD20:         "ISOVIT_AD_20_NIVEL_A_BALDE_15_LT_MACEIRA_RIO_MAIOR",
  ISOVIT_AD25:         "ISOVIT_AD_25_BALDE_15_LT_MACEIRA",
  ISOVIT_REV_SP:       "ISOVIT_REV_SP_BRANCO_SP10A_BALDE_15_LT_MACEIRA",
  ISOVIT_REV_SLS:      "ISOVIT_REV_SLS_0_7_1_2_1_5_BALDE_25_KG_MACEIRA",
  ISOVIT_REDE160:      "ISOVIT_REDE_160_MALHA_4X5_MM_50_M2_1_ROLO_MACEIRA",
  ISOVIT_BUCHA90:      "ISOVIT_BUCHA_DE_FIXACAO_EXPANSIVEL_COM_PREGO_EM_NYLON_90_MM_PACK_200_UN_MACEIRA",
  ISOVIT_ACABAMENTO:   "ISOVIT_PERFIL_DE_CANTO_EM_PVC_COM_REDE_PACK_50_UN_MACEIRA",
};

/* ============================================================
   ISODUR — perfis de arranque 20–100 mm (10 mm steps)
   ============================================================ */
export const ARRANQUE_KEYS = {
  20:  "ISOVIT_PERFIL_DE_ARRANQUE_DE_20_MM_L_2_5M_PACK_20_UN_MACEIRA",
  30:  "ISOVIT_PERFIL_DE_ARRANQUE_DE_30_MM_L_2_5M_PACK_20_UN_MACEIRA",
  40:  "ISOVIT_PERFIL_DE_ARRANQUE_DE_40_MM_L_2_5M_PACK_20_UN_MACEIRA",
  50:  "ISOVIT_PERFIL_DE_ARRANQUE_DE_50_MM_L_2_5M_PACK_20_UN_MACEIRA",
  60:  "ISOVIT_PERFIL_DE_ARRANQUE_DE_60_MM_L_2_5M_PACK_20_UN_MACEIRA",
  70:  "ISOVIT_PERFIL_DE_ARRANQUE_DE_70_MM_L_2_5M_PACK_20_UN_MACEIRA",
  80:  "ISOVIT_PERFIL_DE_ARRANQUE_DE_80_MM_L_2_5M_PACK_20_UN_MACEIRA",
  90:  "ISOVIT_PERFIL_DE_ARRANQUE_DE_90_MM_L_2_5M_PACK_20_UN_MACEIRA",
  100: "ISOVIT_PERFIL_DE_ARRANQUE_DE_100_MM_L_2_5M_PACK_20_UN_MACEIRA",
};

/* ============================================================
   ISOVIT (ETICS) — perfis de arranque por espessura (mm)
   ============================================================ */
export const ISOVIT_ARRANQUE_KEYS = {
  40:  "ISOVIT_PERFIL_DE_ARRANQUE_DE_40_MM_L_2_5M_PACK_20_UN_MACEIRA",
  60:  "ISOVIT_PERFIL_DE_ARRANQUE_DE_60_MM_L_2_5M_PACK_20_UN_MACEIRA",
  80:  "ISOVIT_PERFIL_DE_ARRANQUE_DE_80_MM_L_2_5M_PACK_20_UN_MACEIRA",
  100: "ISOVIT_PERFIL_DE_ARRANQUE_DE_100_MM_L_2_5M_PACK_20_UN_MACEIRA",
  120: "ISOVIT_PERFIL_DE_ARRANQUE_DE_120_MM_L_2_5M_PACK_20_UN_MACEIRA",
  140: "ISOVIT_PERFIL_DE_ARRANQUE_DE_140_MM_L_2_5M_PACK_20_UN_MACEIRA",
  160: "ISOVIT_PERFIL_DE_ARRANQUE_DE_160_MM_L_2_5M_PACK_20_UN_MACEIRA",
  180: "ISOVIT_PERFIL_DE_ARRANQUE_DE_180_MM_L_2_5M_PACK_20_UN_MACEIRA",
  200: "ISOVIT_PERFIL_DE_ARRANQUE_DE_200_MM_L_2_5M_PACK_20_UN_MACEIRA",
};

function isovitArranqueKey(mm) {
  const sizes = [40, 60, 80, 100, 120, 140, 160, 180, 200];
  const size = sizes.find(s => s >= mm) || 200;
  return ISOVIT_ARRANQUE_KEYS[size] || ISOVIT_ARRANQUE_KEYS[200];
}

/* ============================================================
   ISOVIT — tipos de painel e espessuras disponíveis
   ============================================================ */
export const ISOVIT_PANEL_THICKNESSES = {
  eps100:       [10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200],
  eps150:       [20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200],
  eps80grafite: [10,20,30,40,50,60,70,80,90,100,120,140,160,180,200],
  icb:          [20,25,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200,230,250,270,300],
  icb_md:       [40,50,60,80,100,200],
  icb_md_wave:  [40,50,70,100],
  wf:           [60,80],
  mw_fkd_s:    [40,50,60,80,100],
};

export const ISOVIT_PANEL_KEYS = {
  eps100: {
    10:'PAINEL_DE_EPS_100_DE_10MM_PACK_60_M2_MACEIRA', 20:'PAINEL_DE_EPS_100_DE_20MM_PACK_30_M2_MACEIRA',
    30:'PAINEL_DE_EPS_100_DE_30MM_PACK_20_M2_MACEIRA', 40:'PAINEL_DE_EPS_100_DE_40MM_PACK_15_M2_MACEIRA',
    50:'PAINEL_DE_EPS_100_DE_50MM_PACK_12_M2_MACEIRA', 60:'PAINEL_DE_EPS_100_DE_60MM_PACK_10_M2_MACEIRA',
    70:'PAINEL_DE_EPS_100_DE_70MM_PACK_8_M2_MACEIRA',  80:'PAINEL_DE_EPS_100_DE_80MM_PACK_7_M2_MACEIRA',
    90:'PAINEL_DE_EPS_100_DE_90MM_PACK_6_M2_MACEIRA',  100:'PAINEL_DE_EPS_100_DE_100MM_PACK_6_M2_MACEIRA',
    110:'PAINEL_DE_EPS_100_DE_110MM_PACK_5_M2_MACEIRA',120:'PAINEL_DE_EPS_100_DE_120MM_PACK_5_M2_MACEIRA',
    130:'PAINEL_DE_EPS_100_DE_130MM_PACK_4_M2_MACEIRA',140:'PAINEL_DE_EPS_100_DE_140MM_PACK_4_M2_MACEIRA',
    150:'PAINEL_DE_EPS_100_DE_150MM_PACK_4_M2_MACEIRA',160:'PAINEL_DE_EPS_100_DE_160MM_PACK_3_M2_MACEIRA',
    170:'PAINEL_DE_EPS_100_DE_170MM_PACK_3_M2_MACEIRA',180:'PAINEL_DE_EPS_100_DE_180MM_PACK_3_M2_MACEIRA',
    190:'PAINEL_DE_EPS_100_DE_190MM_PACK_3_M2_MACEIRA',200:'PAINEL_DE_EPS_100_DE_200MM_PACK_3_M2_MACEIRA',
  },
  eps150: {
    20:'PAINEL_DE_EPS_150_DE_20MM_PACK_30_M2_MACEIRA', 30:'PAINEL_DE_EPS_150_DE_30MM_PACK_20_M2_MACEIRA',
    40:'PAINEL_DE_EPS_150_DE_40MM_PACK_15_M2_MACEIRA', 50:'PAINEL_DE_EPS_150_DE_50MM_PACK_12_M2_MACEIRA',
    60:'PAINEL_DE_EPS_150_DE_60MM_PACK_10_M2_MACEIRA', 70:'PAINEL_DE_EPS_150_DE_70MM_PACK_8_M2_MACEIRA',
    80:'PAINEL_DE_EPS_150_DE_80MM_PACK_7_M2_MACEIRA',  90:'PAINEL_DE_EPS_150_DE_90MM_PACK_6_M2_MACEIRA',
    100:'PAINEL_DE_EPS_150_DE_100MM_PACK_6_M2_MACEIRA',110:'PAINEL_DE_EPS_150_DE_110MM_PACK_5_M2_MACEIRA',
    120:'PAINEL_DE_EPS_150_DE_120MM_PACK_5_M2_MACEIRA',130:'PAINEL_DE_EPS_150_DE_130MM_PACK_4_M2_MACEIRA',
    140:'PAINEL_DE_EPS_150_DE_140MM_PACK_4_M2_MACEIRA',150:'PAINEL_DE_EPS_150_DE_150MM_PACK_4_M2_MACEIRA',
    160:'PAINEL_DE_EPS_150_DE_160MM_PACK_3_M2_MACEIRA',170:'PAINEL_DE_EPS_150_DE_170MM_PACK_3_M2_MACEIRA',
    180:'PAINEL_DE_EPS_150_DE_180MM_PACK_3_M2_MACEIRA',190:'PAINEL_DE_EPS_150_DE_190MM_PACK_3_M2_MACEIRA',
    200:'PAINEL_DE_EPS_150_DE_200MM_PACK_3_M2_MACEIRA',
  },
  eps80grafite: {
    10:'PAINEL_DE_EPS_80_GRAFITE_DE_10MM_NOVO_PACK_60_M2_MACEIRA', 20:'PAINEL_DE_EPS_80_GRAFITE_DE_20MM_NOVO_PACK_30_M2_MACEIRA',
    30:'PAINEL_DE_EPS_80_GRAFITE_DE_30MM_NOVO_PACK_20_M2_MACEIRA', 40:'PAINEL_DE_EPS_80_GRAFITE_DE_40MM_NOVO_PACK_15_M2_MACEIRA',
    50:'PAINEL_DE_EPS_80_GRAFITE_DE_50MM_NOVO_PACK_12_M2_MACEIRA', 60:'PAINEL_DE_EPS_80_GRAFITE_DE_60MM_NOVO_PACK_10_M2_MACEIRA',
    70:'PAINEL_DE_EPS_80_GRAFITE_DE_70MM_NOVO_PACK_8_M2_MACEIRA',  80:'PAINEL_DE_EPS_80_GRAFITE_DE_80MM_NOVO_PACK_7_M2_MACEIRA',
    90:'PAINEL_DE_EPS_80_GRAFITE_DE_90MM_NOVO_PACK_6_M2_MACEIRA',  100:'PAINEL_DE_EPS_80_GRAFITE_DE_100MM_NOVO_PACK_6_M2_MACEIRA',
    120:'PAINEL_DE_EPS_80_GRAFITE_DE_120MM_NOVO_PACK_5_M2_MACEIRA',140:'PAINEL_DE_EPS_80_GRAFITE_DE_140MM_NOVO_PACK_4_M2_MACEIRA',
    160:'PAINEL_DE_EPS_80_GRAFITE_DE_160MM_NOVO_PACK_4_M2_MACEIRA',180:'PAINEL_DE_EPS_80_GRAFITE_DE_180MM_NOVO_PACK_3_M2_MACEIRA',
    200:'PAINEL_DE_EPS_80_GRAFITE_DE_200MM_NOVO_PACK_3_M2_MACEIRA',
  },
  icb: {
    20:'PAINEL_DE_ICB_DE_20_MM_PACK_7_5_M2_MACEIRA',  25:'PAINEL_DE_ICB_DE_25_MM_PACK_6_0_M2_MACEIRA',
    30:'PAINEL_DE_ICB_DE_30_MM_PACK_5_0_M2_MACEIRA',  40:'PAINEL_DE_ICB_DE_40_MM_PACK_4_0_M2_MACEIRA',
    50:'PAINEL_DE_ICB_DE_50_MM_PACK_3_0_M2_MACEIRA',  60:'PAINEL_DE_ICB_DE_60_MM_PACK_2_5_M2_MACEIRA',
    70:'PAINEL_DE_ICB_DE_70_MM_PACK_2_0_M2_MACEIRA',  80:'PAINEL_DE_ICB_DE_80_MM_PACK_2_0_M2_MACEIRA',
    90:'PAINEL_DE_ICB_DE_90_MM_PACK_1_5_M2_MACEIRA',  100:'PAINEL_DE_ICB_DE_100_MM_PACK_1_5_M2_MACEIRA',
    110:'PAINEL_DE_ICB_DE_110_MM_PACK_1_0_M2_MACEIRA',120:'PAINEL_DE_ICB_DE_120_MM_PACK_1_0_M2_MACEIRA',
    130:'PAINEL_DE_ICB_DE_130_MM_PACK_1_0_M2_MACEIRA',140:'PAINEL_DE_ICB_DE_140_MM_PACK_1_0_M2_MACEIRA',
    150:'PAINEL_DE_ICB_DE_150_MM_PACK_1_0_M2_MACEIRA',160:'PAINEL_DE_ICB_DE_160_MM_PACK_1_0_M2_MACEIRA',
    170:'PAINEL_DE_ICB_DE_170_MM_PACK_0_5_M2_MACEIRA',180:'PAINEL_DE_ICB_DE_180_MM_PACK_0_5_M2_MACEIRA',
    190:'PAINEL_DE_ICB_DE_190_MM_PACK_0_5_M2_MACEIRA',200:'PAINEL_DE_ICB_DE_200_MM_PACK_0_5_M2_MACEIRA',
    230:'PAINEL_DE_ICB_DE_230_MM_PACK_0_5_M2_MACEIRA',250:'PAINEL_DE_ICB_DE_250_MM_PACK_0_5_M2_MACEIRA',
    270:'PAINEL_DE_ICB_DE_270_MM_PACK_0_5_M2_MACEIRA',300:'PAINEL_DE_ICB_DE_300_MM_PACK_0_5_M2_MACEIRA',
  },
  icb_md: {
    40:'PAINEL_ICB_MD_DE_40_MM_PACK_4_0_M2_MACEIRA', 50:'PAINEL_ICB_MD_DE_50_MM_PACK_3_0_M2_MACEIRA',
    60:'PAINEL_ICB_MD_DE_60_MM_PACK_2_5_M2_MACEIRA', 80:'PAINEL_ICB_MD_DE_80_MM_PACK_2_0_M2_MACEIRA',
    100:'PAINEL_ICB_MD_DE_100_MM_PACK_1_5_M2_MACEIRA',200:'PAINEL_ICB_MD_DE_200_MM_PACK_0_5_M2_MACEIRA',
  },
  icb_md_wave: {
    40:'PAINEL_ICB_MD_WAVE_DE_40_MM_PACK_4_0_M2_MACEIRA', 50:'PAINEL_ICB_MD_WAVE_DE_50_MM_PACK_3_0_M2_MACEIRA',
    70:'PAINEL_ICB_MD_WAVE_DE_70_MM_PACK_2_0_M2_MACEIRA', 100:'PAINEL_ICB_MD_WAVE_DE_100_MM_PACK_1_5_M2_MACEIRA',
  },
  wf: {
    60:'PAINEL_WF_DE_60MM_PACK_18_24_M2_MACEIRA', 80:'PAINEL_WF_DE_80MM_PACK_13_44_M2_MACEIRA',
  },
  mw_fkd_s: {
    40:'PAINEL_MW_FKD_S_40_MM_PACK_3_60_M2_MACEIRA', 50:'PAINEL_MW_FKD_S_50_MM_PACK_4_20_M2_MACEIRA',
    60:'PAINEL_MW_FKD_S_60_MM_PACK_3_00_M2_MACEIRA', 80:'PAINEL_MW_FKD_S_80_MM_PACK_2_40_M2_MACEIRA',
    100:'PAINEL_MW_FKD_S_100_MM_PACK_1_80_M2_MACEIRA',
  },
};

export const ISOVIT_PANEL_COVER = {
  eps100:       {10:60,20:30,30:20,40:15,50:12,60:10,70:8,80:7,90:6,100:6,110:5,120:5,130:4,140:4,150:4,160:3,170:3,180:3,190:3,200:3},
  eps150:       {20:30,30:20,40:15,50:12,60:10,70:8,80:7,90:6,100:6,110:5,120:5,130:4,140:4,150:4,160:3,170:3,180:3,190:3,200:3},
  eps80grafite: {10:60,20:30,30:20,40:15,50:12,60:10,70:8,80:7,90:6,100:6,120:5,140:4,160:4,180:3,200:3},
  icb:          {20:7.5,25:6.0,30:5.0,40:4.0,50:3.0,60:2.5,70:2.0,80:2.0,90:1.5,100:1.5,110:1.0,120:1.0,130:1.0,140:1.0,150:1.0,160:1.0,170:0.5,180:0.5,190:0.5,200:0.5,230:0.5,250:0.5,270:0.5,300:0.5},
  icb_md:       {40:4.0,50:3.0,60:2.5,80:2.0,100:1.5,200:0.5},
  icb_md_wave:  {40:4.0,50:3.0,70:2.0,100:1.5},
  wf:           {60:18.24,80:13.44},
  mw_fkd_s:    {40:3.60,50:4.20,60:3.00,80:2.40,100:1.80},
};

/* ============================================================
   ISODUR — promotor de aderência
   ============================================================ */
export const ISODUR_PROMOTOR_KEYS = {
  red_fix: "REDUR_RED_FIX_SACO_25_KG_PATAIAS_MONTIJO",
  cal_cs:  "REABILITA_CAL_CS_SACO_25_KG_MONTIJO_PATAIAS",
  ad90:    "REDUR_AD_90_BALDE_20_KG_MACEIRA",
};
export const ISODUR_PROMOTOR_SPEC = {
  red_fix: { kg: 5.0, pack: 25 },
  cal_cs:  { kg: 3.0, pack: 25 },
  ad90:    { kg: 1.0, pack: 20 },
};

/* ============================================================
   ISOVIT REV — consumo (kg/m²) por granulometria
   ============================================================ */
export const ISOVIT_REV_KG_PER_M2 = { "07": 1.6, "12": 2.0, "15": 2.4 };

/* ============================================================
   REDUR — rebocos
   ============================================================ */
export const REDUR_REBOCO_KEYS = {
  irp_ext:   "REDUR_IRP_EXTERIOR_SACO_25_KG_RIO_MAIOR",
  irp_int:   "REDUR_IRP_INTERIOR_SACO_25_KG_RIO_MAIOR",
  irp_man:   "REDUR_IRP_MANUAL_SACO_25_KG_RIO_MAIOR",
  branco:    "REDUR_BRANCO_SACO_25_KG_RIO_MAIOR",
  medio:     "REDUR_MEDIO_SACO_25_KG_MONTIJO_PATAIAS",
  manual:    "REDUR_MANUAL_SACO_25_KG_MONTIJO_PATAIAS",
  multi:     "REDUR_MULTI_SACO_25_KG_MONTIJO_PATAIAS",
  max_fibra: "REDUR_MAX_FIBRA_H_2_SACO_25_KG_RIO_MAIOR",
  max_force: "REDUR_MAX_FORCE_SACO_25_KG_MONTIJO_RIO_MAIOR_PATAIAS",
  h_one:     "REDUR_H_ONE_INTERIOR_SACO_25_KG_RIO_MAIOR",
};

export const REDUR_REBOCO_KG = {
  irp_ext: 14, irp_int: 14, irp_man: 14,
  branco:  15, medio:   13, manual:  13,
  multi:   13, max_fibra: 14.5, max_force: 12, h_one: 14,
};

/* ============================================================
   REDUR — promotor de aderência
   ============================================================ */
export const REDUR_PROMOTOR_KEYS = {
  red_fix:  "REDUR_RED_FIX_SACO_25_KG_PATAIAS_MONTIJO",
  chapisco: "REDUR_CHAPISCO_SACO_25_KG_MONTIJO_PATAIAS",
  fix:      "REDUR_FIX_SACO_25_KG_RIO_MAIOR",
  ad90:     "REDUR_AD_90_BALDE_20_KG_MACEIRA",
};
export const REDUR_PROMOTOR_SPEC = {
  red_fix:  { kg: 5.0, pack: 25 },
  chapisco: { kg: 5.0, pack: 25 },
  fix:      { kg: 5.0, pack: 25 },
  ad90:     { kg: 1.0, pack: 20 },
};

/* ============================================================
   REDUR — acabamentos
   ============================================================ */
export const REDUR_ACABAMENTO_KEYS = {
  pk02:        "REDUR_PK_02_BALDE_25_KG_MACEIRA_RIO_MAIOR",
  pk06:        "REDUR_PK_06_SACO_20_KG_MONTIJO_RIO_MAIOR_PATAIAS",
  pk08:        "REDUR_PK_08_SACO_20_KG_MONTIJO_RIO_MAIOR_PATAIAS",
  pk20b:       "REDUR_PK_20_BRANCO_SACO_25_KG_MONTIJO_RIO_MAIOR_PATAIAS",
  pk20c:       "REDUR_PK_20_CINZA_SACO_25_KG_MONTIJO_RIO_MAIOR_PATAIAS",
  kcolor_k11a: "REDUR_K_COLOR_K11A_SACO_25_KG_RIO_MAIOR",
  kcolor_cat:  "REDUR_K_COLOR_RESTANTES_CORES_DE_CATALOGO_SACO_25_KG_RIO_MAIOR",
  rs12:        "REABILITA_RS_12_SACO_20_KG_MONTIJO_PATAIAS",
  rr20:        "REABILITA_RR_20_SACO_25_KG_MONTIJO_PATAIAS",
  pk_flex:     "ISODUR_PK_FLEX_SACO_25_KG_MONTIJO_RIO_MAIOR_PATAIAS",
};

export const REDUR_ACABAMENTO_SPEC = {
  pk02:        { kg: 2.8, pack: 25 },
  pk06:        { kg: 2.0, pack: 20 },
  pk08:        { kg: 2.0, pack: 20 },
  pk20b:       { kg: 2.0, pack: 25 },
  pk20c:       { kg: 2.0, pack: 25 },
  kcolor_k11a: { kg: 2.0, pack: 25 },
  kcolor_cat:  { kg: 2.0, pack: 25 },
  rs12:        { kg: 2.5, pack: 20 },
  rr20:        { kg: 3.0, pack: 25 },
  pk_flex:     { kg: 4.0, pack: 25 },
};

/* ============================================================
   BECORK — argamassas térmicas
   ============================================================ */
export const BECORK_KEYS = {
  lime:   "BECORK_LIME_SACO_14_KG_MONTIJO_PATAIAS",
  render: "BECORK_RENDER_SACO_12_KG_MONTIJO_PATAIAS",
  floor:  "BECORK_FLOOR_SACO_10_KG_MONTIJO_PATAIAS",
};

export const BECORK_SPEC = {
  lime:   { kg: 7.0, pack: 14 },
  render: { kg: 6.5, pack: 12 },
  floor:  { kg: 5.6, pack: 10 },
};

/* ============================================================
   ADHERE — colas cerâmicas
   ============================================================ */
export const ADHERE_COLA_KEYS = {
  ci10_cinza:      "ADHERE_CI_1_0_CINZA_SACO_25_KG_MONTIJO_PATAIAS",
  ci10_branco:     "ADHERE_CI_1_0_BRANCO_SACO_25_KG_MONTIJO_PATAIAS",
  ci19_cinza:      "ADHERE_CI_1_9_CINZA_SACO_25_KG_MONTIJO_PATAIAS",
  ci19_branco:     "ADHERE_CI_1_9_BRANCO_SACO_25_KG_MONTIJO_PATAIAS",
  flex_cc_cinza:   "ADHERE_FLEX_CC_CINZA_SACO_25_KG_MONTIJO_PATAIAS",
  flex_cc_branco:  "ADHERE_FLEX_CC_BRANCO_SACO_25_KG_MONTIJO_PATAIAS",
  flex_tt_cinza:   "ADHERE_FLEX_TT_CINZA_SACO_25_KG_MONTIJO_PATAIAS",
  flex_tt_branco:  "ADHERE_FLEX_TT_BRANCO_SACO_25_KG_MONTIJO_PATAIAS",
  flex_tt_gel:     "ADHERE_FLEX_TT_GEL_SACO_25_KG_MONTIJO_PATAIAS",
  flex_tt_pro_cinza:  "ADHERE_FLEX_TT_PRO_CINZA_SACO_25_KG_MONTIJO_PATAIAS",
  flex_tt_pro_branco: "ADHERE_FLEX_TT_PRO_BRANCO_SACO_25_KG_MONTIJO_PATAIAS",
  flex_gt_cinza:   "ADHERE_FLEX_GT_CINZA_SACO_25_KG_MONTIJO_PATAIAS",
  flex_gt_branco:  "ADHERE_FLEX_GT_BRANCO_SACO_25_KG_MONTIJO_PATAIAS",
  flex_f1:         "ADHERE_FLEX_F1_BRANCO_SACO_25_KG_MONTIJO_PATAIAS",
  turbo:           "ADHERE_TURBO_CINZA_SACO_25_KG_MONTIJO_PATAIAS",
  hidro:           "ADHERE_HIDRO_SACO_25_KG_MONTIJO_PATAIAS",
};

export const ADHERE_COR_KEYS = {
  cor05_a:   "ADHERE_COR_05_GRUPO_A_SACO_5_KG_MACEIRA",
  cor05_b:   "ADHERE_COR_05_GRUPO_B_SACO_5_KG_MACEIRA",
  cor05_c:   "ADHERE_COR_05_GRUPO_C_SACO_5_KG_MACEIRA",
  cor312_a:  "ADHERE_COR_312_GRUPO_A_SACO_5_KG_MACEIRA",
  cor312_b:  "ADHERE_COR_312_GRUPO_B_SACO_5_KG_MACEIRA",
  cor312_c:  "ADHERE_COR_312_GRUPO_C_SACO_5_KG_MACEIRA",
};

/* ============================================================
   HIDROSTOP — impermeabilizações
   ============================================================ */
export const HIDROSTOP_PROD_KEYS = {
  flex:          "HIDROSTOP_FLEX_SACO_20_KG_MONTIJO_PATAIAS",
  elastico:      "HIDROSTOP_ELASTICO_BALDE_15_KG_MACEIRA",
  elasticofibras:"HIDROSTOP_ELASTICO_FIBRAS_BALDE_15_KG_MACEIRA",
  resist:        "HIDROSTOP_RESIST_SACO_25_KG_MONTIJO_PATAIAS",
};

export const HIDROSTOP_PROD_SPEC = {
  flex:          { kg: 3, pack: 20 },
  elastico:      { kg: 3, pack: 15 },
  elasticofibras:{ kg: 3, pack: 15 },
  resist:        { kg: 6, pack: 25 },
};

/* ============================================================
   REABILITA — consolidação, reboco, barramento, pintura e redes
   Espessuras de referência: 15 mm para consolidação e reboco
   ============================================================ */
export const REAB_CONSOL_KEYS = {
  cal_cs: "REABILITA_CAL_CS_SACO_25_KG_MONTIJO_PATAIAS",
  ra01:   "REABILITA_RA_01_SACO_25_KG_MONTIJO_PATAIAS",
};
export const REAB_CONSOL_KG = { cal_cs: 18, ra01: 18 };

export const REAB_REBOCO_KEYS = {
  cal_rb: "REABILITA_CAL_RB_SACO_25_KG_MONTIJO_PATAIAS",
  ra01:   "REABILITA_RA_01_SACO_25_KG_MONTIJO_PATAIAS",
  cal_mp: "REABILITA_CAL_MP_SACO_25_KG_MONTIJO_PATAIAS",
  ra05:   "REABILITA_RA_05_SACO_25_KG_MONTIJO_PATAIAS",
};
export const REAB_REBOCO_KG = { cal_rb: 12, ra01: 18, cal_mp: 14, ra05: 15 };

export const REAB_ACAB_KEYS = {
  cal_ac:      "REABILITA_CAL_AC_AC01_NATURAL_SACO_25_KG_MONTIJO_PATAIAS",
  cal_ac_fino: "REABILITA_CAL_AC_FINO_AC01_NATURAL_SACO_18_KG_MONTIJO_PATAIAS",
  rr20:        "REABILITA_RR_20_SACO_25_KG_MONTIJO_PATAIAS",
  rs34:        "REABILITA_RS_34_SACO_25_KG_MONTIJO_PATAIAS",
};
export const REAB_ACAB_SPEC = {
  cal_ac:      { kg: 2.4, pack: 25 },
  cal_ac_fino: { kg: 1.5, pack: 18 },
  rr20:        { kg: 3.0, pack: 25 },
  rs34:        { kg: 1.5, pack: 25 },
};

/* ============================================================
   ISOVIT (ETICS) — colagem/barramento e acabamentos
   ============================================================ */
export const ISOVIT_COLAGEM_KEYS = {
  fibra:     "ISOVIT_FIBRA_SACO_25_KG_MONTIJO_RIO_MAIOR_PATAIAS",
  fibraflex: "ISOVIT_FIBRAFLEX_SACO_25_KG_MONTIJO_RIO_MAIOR_PATAIAS",
  corkflex:  "ISOVIT_CORKFLEX_MD_SACO_20_KG_MONTIJO_PATAIAS",
  lightflex: "ISOVIT_LIGHTFLEX_SACO_20_KG_MONTIJO_PATAIAS",
  easypro:   "ISOVIT_EASYPRO_NOVO_SACO_25_KG_MONTIJO_RIO_MAIOR_PATAIAS",
  lime:      "ISOVIT_LIME_SACO_20_KG_MONTIJO_PATAIAS",
};
export const ISOVIT_COLAGEM_SPEC = {
  fibra:     { kg: 4, pack: 25 },
  fibraflex: { kg: 4, pack: 25 },
  corkflex:  { kg: 4, pack: 20 },
  lightflex: { kg: 4, pack: 20 },
  easypro:   { kg: 4, pack: 25 },
  lime:      { kg: 4, pack: 20 },
};

export const ISOVIT_ACAB_KEYS = {
  rev_a:   "ISOVIT_REV_0_7_1_2_1_5_NIVEL_A_BALDE_25_KG_MACEIRA_RIO_MAIOR",
  rev_b:   "ISOVIT_REV_0_7_1_2_1_5_NIVEL_B_BALDE_25_KG_MACEIRA_RIO_MAIOR",
  rev_sp:  "ISOVIT_REV_SP_BRANCO_SP10A_BALDE_15_LT_MACEIRA",
  rev_sls: "ISOVIT_REV_SLS_0_7_1_2_1_5_BALDE_25_KG_MACEIRA",
};
export const ISOVIT_ACAB_COVER = {
  rev_a: 25, rev_b: 25, rev_sp: 15, rev_sls: 25,
};

/* ============================================================
   REGRAS DE MATERIAIS
   ============================================================ */

function mc12_3(totalKg) {
  const large = Math.max(0, Math.floor(totalKg / 12) - 1);
  const small  = Math.ceil((totalKg - large * 12) / 3);
  return { large, small };
}

export const materialRules = {
  microart: [
    /* Primário AD21 */
    { productKey: PRODUCT_KEYS.MICRO_AD21_5,
      base: "Primário — 1 balde / 80 m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area / 80)) },

    /* Rede 90 — checkbox opcional */
    { productKey: PRODUCT_KEYS.MICRO_REDE90,
      skip: ({ microartRede90 }) => !microartRede90,
      base: "Rede 90 — 1 rolo / 50 m² (+10% desperdício)",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 1.1 / 50)) },

    /* MC-01 baldes 12 kg */
    { getProductKey: ({ corMc01 }) =>
        corMc01 === "catalogo" ? PRODUCT_KEYS.MICRO_MC01_CORES_12 : PRODUCT_KEYS.MICRO_MC01_BASE_12,
      base: ({ suporte }) => suporte === "parede"
        ? "MC-01 — 3,2 kg/m² (baldes 12 kg)"
        : "MC-01 — 4,6 kg/m² (baldes 12 kg)",
      skip: ({ area, suporte }) => {
        const total = Math.ceil(area * (suporte === "parede" ? 3.2 : 4.6));
        return mc12_3(total).large === 0;
      },
      qty: ({ area, suporte }) => {
        const total = Math.ceil(area * (suporte === "parede" ? 3.2 : 4.6));
        return mc12_3(total).large;
      } },

    /* MC-01 baldes 3 kg (complemento) */
    { getProductKey: ({ corMc01 }) =>
        corMc01 === "catalogo" ? PRODUCT_KEYS.MICRO_MC01_CORES_3 : PRODUCT_KEYS.MICRO_MC01_BASE_3,
      base: ({ suporte }) => suporte === "parede"
        ? "MC-01 — 3,2 kg/m² (baldes 3 kg)"
        : "MC-01 — 4,6 kg/m² (baldes 3 kg)",
      qty: ({ area, suporte }) => {
        const total = Math.ceil(area * (suporte === "parede" ? 3.2 : 4.6));
        return mc12_3(total).small;
      } },

    /* MC-02 baldes 12 kg */
    { productKey: PRODUCT_KEYS.MICRO_MC02_CORES_12,
      base: "Acabamento — 1,2 kg/m² (baldes 12 kg)",
      skip: ({ area }) => mc12_3(Math.ceil(area * 1.2)).large === 0,
      qty: ({ area }) => mc12_3(Math.ceil(area * 1.2)).large },

    /* MC-02 baldes 3 kg (complemento) */
    { productKey: PRODUCT_KEYS.MICRO_MC02_CORES_3,
      base: "Acabamento — 1,2 kg/m² (baldes 3 kg)",
      qty: ({ area }) => mc12_3(Math.ceil(area * 1.2)).small },

    /* Selante AD50 */
    { productKey: PRODUCT_KEYS.MICRO_AD50_55,
      base: "Selante — 1 balde / 60 m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area / 60)) },

    /* Proteção AD92 — baldes 5 lt */
    { productKey: PRODUCT_KEYS.MICRO_AD92_5,
      base: "Proteção — 3 demãos (baldes 5 lt)",
      skip: ({ area }) => Math.ceil(area / 12) < 5,
      qty: ({ area }) => Math.floor(Math.ceil(area / 12) / 5) },

    /* Proteção AD92 — baldes 1 lt (complemento) */
    { productKey: PRODUCT_KEYS.MICRO_AD92_1,
      base: "Proteção — 3 demãos (baldes 1 lt)",
      skip: ({ area }) => Math.ceil(area / 12) % 5 === 0,
      qty: ({ area }) => {
        const totalL = Math.ceil(area / 12);
        const rem    = totalL % 5;
        return rem > 0 ? rem : totalL;
      } },
  ],

  isodur: [
    { getProductKey: ({ isodurPromotor }) => ISODUR_PROMOTOR_KEYS[isodurPromotor] || null,
      skip: ({ isodurPromotor }) => !isodurPromotor || isodurPromotor === "sem",
      base: ({ isodurPromotor }) => {
        const s = ISODUR_PROMOTOR_SPEC[isodurPromotor];
        return s ? `Promotor — ${s.kg} kg/m²` : "Promotor";
      },
      qty: ({ area, isodurPromotor }) => {
        const s = ISODUR_PROMOTOR_SPEC[isodurPromotor];
        return s ? Math.max(1, Math.ceil(area * s.kg / s.pack)) : 0;
      } },

    { productKey: PRODUCT_KEYS.ISODUR_ONE,
      base: "Argamassa térmica — 1 saco/m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area)) },

    { productKey: PRODUCT_KEYS.ISOVIT_REDE160,
      base: "Rede — 1 rolo / 50 m² (+10% desperdício)",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 1.1 / 50)) },

    { productKey: PRODUCT_KEYS.ISODUR_PK_FLEX,
      skip: ({ isodurSistema }) => isodurSistema !== "areado",
      base: "Barramento areado — 4 kg/m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 4 / 25)) },

    { productKey: PRODUCT_KEYS.ISOVIT_FIBRAFLEX,
      skip: ({ isodurSistema }) => !["liso_ext","liso_int","acrilico"].includes(isodurSistema),
      base: "Barramento — 4 kg/m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 4 / 25)) },

    { productKey: PRODUCT_KEYS.ISOVIT_LIGHTFLEX,
      skip: ({ isodurSistema }) => isodurSistema !== "cal_ac",
      base: "Barramento cal — 4 kg/m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 4 / 20)) },

    { productKey: REDUR_ACABAMENTO_KEYS.pk02,
      skip: ({ isodurSistema }) => isodurSistema !== "liso_ext",
      base: `Acabamento — ${REDUR_ACABAMENTO_SPEC.pk02.kg} kg/m²`,
      qty: ({ area }) => Math.max(1, Math.ceil(area * REDUR_ACABAMENTO_SPEC.pk02.kg / REDUR_ACABAMENTO_SPEC.pk02.pack)) },

    { productKey: REDUR_ACABAMENTO_KEYS.pk06,
      skip: ({ isodurSistema }) => isodurSistema !== "liso_int",
      base: `Acabamento — ${REDUR_ACABAMENTO_SPEC.pk06.kg} kg/m²`,
      qty: ({ area }) => Math.max(1, Math.ceil(area * REDUR_ACABAMENTO_SPEC.pk06.kg / REDUR_ACABAMENTO_SPEC.pk06.pack)) },

    { productKey: PRODUCT_KEYS.ISOVIT_AD20,
      skip: ({ isodurSistema }) => isodurSistema !== "acrilico",
      base: "Primário AD20 — 1 balde / 75 m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area / 75)) },

    { getProductKey: () => ISOVIT_ACAB_KEYS.rev_a,
      skip: ({ isodurSistema }) => isodurSistema !== "acrilico",
      base: ({ isodurGranulo }) => {
        const kg = ISOVIT_REV_KG_PER_M2[isodurGranulo] || 2.0;
        return `Acabamento acrílico — ${kg} kg/m²`;
      },
      qty: ({ area, isodurGranulo }) => {
        const kg = ISOVIT_REV_KG_PER_M2[isodurGranulo] || 2.0;
        return Math.max(1, Math.ceil(area * kg / 25));
      } },

    { productKey: "REABILITA_CAL_AC_AC01_NATURAL_SACO_25_KG_MONTIJO_PATAIAS",
      skip: ({ isodurSistema }) => isodurSistema !== "cal_ac",
      base: "Cal AC — 2,4 kg/m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 2.4 / 25)) },

    { productKey: "REABILITA_CAL_AC_FINO_AC01_NATURAL_SACO_18_KG_MONTIJO_PATAIAS",
      skip: ({ isodurSistema, isodurCalAcFino }) => isodurSistema !== "cal_ac" || !isodurCalAcFino,
      base: "Cal AC Fino — 1,5 kg/m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 1.5 / 18)) },

    { productKey: "B_REPARA_PROTECAO_AD_40_JERRICAN_5_LT_MACEIRA",
      skip: ({ isodurTopCoat }) => isodurTopCoat !== "ad40",
      base: "Pintura AD40 — 1 lt / 2,5 m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area / 12.5)) },

    { productKey: PRODUCT_KEYS.ISOVIT_AD25,
      skip: ({ isodurTopCoat }) => isodurTopCoat !== "ad25_revsp",
      base: "Primário AD25 — 1 balde / 75 m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area / 75)) },

    { productKey: PRODUCT_KEYS.ISOVIT_REV_SP,
      skip: ({ isodurTopCoat }) => isodurTopCoat !== "ad25_revsp",
      base: "Rev SP — 1 balde / 15 m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area / 15)) },

    { getProductKey: ({ espessura }) => ARRANQUE_KEYS[espessura] || ARRANQUE_KEYS[60],
      base: "Perfil de arranque (Pack 20 un × 2,5 m)",
      qty: ({ area }) => Math.max(1, Math.ceil(4 * Math.sqrt(area) / (20 * 2.5))) },

    { productKey: PRODUCT_KEYS.ISOVIT_ACABAMENTO,
      base: "Perfil de canto (Pack 50 un × 2,5 m)",
      qty: ({ acabamento }) => Math.max(0, Math.ceil(acabamento / (50 * 2.5))) },
  ],

  redur: [
    { getProductKey: ({ redurPromotor }) => REDUR_PROMOTOR_KEYS[redurPromotor] || null,
      skip: ({ redurPromotor }) => !redurPromotor || redurPromotor === "sem",
      base: ({ redurPromotor }) => {
        const s = REDUR_PROMOTOR_SPEC[redurPromotor];
        return s ? `Promotor — ${s.kg} kg/m²` : "Promotor";
      },
      qty: ({ area, redurPromotor }) => {
        const s = REDUR_PROMOTOR_SPEC[redurPromotor];
        return s ? Math.max(1, Math.ceil(area * s.kg / s.pack)) : 0;
      } },

    { getProductKey: ({ redurReboco }) => REDUR_REBOCO_KEYS[redurReboco] || REDUR_REBOCO_KEYS.irp_ext,
      base: ({ redurReboco, redurEspessura }) => {
        const baseKg = REDUR_REBOCO_KG[redurReboco] || 14;
        const esp    = redurEspessura || 15;
        return `Reboco — ${(baseKg * esp / 15).toFixed(1)} kg/m²`;
      },
      qty: ({ area, redurReboco, redurEspessura }) => {
        const baseKg = REDUR_REBOCO_KG[redurReboco] || 14;
        const esp    = redurEspessura || 15;
        return Math.max(1, Math.ceil(area * baseKg * esp / (15 * 25)));
      } },

    { productKey: "REDUR_REDE_115_50_M2_1_ROLO_MACEIRA",
      skip: ({ redurRede, redurEspessura }) => !redurRede || (redurEspessura || 0) <= 20,
      base: "Rede 115 — 1 rolo / 50 m² (+10% desperdício)",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 1.1 / 50)) },

    { getProductKey: ({ redurAcabamento }) => REDUR_ACABAMENTO_KEYS[redurAcabamento] || null,
      skip: ({ redurAcabamento }) => !redurAcabamento || redurAcabamento === "sem",
      base: ({ redurAcabamento }) => {
        const s = REDUR_ACABAMENTO_SPEC[redurAcabamento];
        return s ? `Acabamento — ${s.kg} kg/m²` : "Acabamento";
      },
      qty: ({ area, redurAcabamento }) => {
        const s = REDUR_ACABAMENTO_SPEC[redurAcabamento];
        return s ? Math.max(1, Math.ceil(area * s.kg / s.pack)) : 0;
      } },
  ],

  becork: [
    { getProductKey: ({ becorkPromotor }) => ISODUR_PROMOTOR_KEYS[becorkPromotor] || null,
      skip: ({ becorkPromotor }) => !becorkPromotor || becorkPromotor === "sem",
      base: ({ becorkPromotor }) => {
        const s = ISODUR_PROMOTOR_SPEC[becorkPromotor];
        return s ? `Promotor — ${s.kg} kg/m²` : "Promotor";
      },
      qty: ({ area, becorkPromotor }) => {
        const s = ISODUR_PROMOTOR_SPEC[becorkPromotor];
        return s ? Math.max(1, Math.ceil(area * s.kg / s.pack)) : 0;
      } },

    { getProductKey: ({ becorkProd }) => BECORK_KEYS[becorkProd] || BECORK_KEYS.lime,
      base: ({ becorkProd, becorkEspessura }) => {
        const s   = BECORK_SPEC[becorkProd] || BECORK_SPEC.lime;
        const esp = becorkEspessura || 20;
        return `Argamassa — ${(s.kg * esp / 10).toFixed(1)} kg/m²`;
      },
      qty: ({ area, becorkProd, becorkEspessura }) => {
        const s   = BECORK_SPEC[becorkProd] || BECORK_SPEC.lime;
        const esp = becorkEspessura || 20;
        return Math.max(1, Math.ceil(area * s.kg * esp / (10 * s.pack)));
      } },

    { productKey: "REDUR_REDE_115_50_M2_1_ROLO_MACEIRA",
      skip: ({ becorkProd, becorkRede }) => !becorkRede || becorkProd === "floor",
      base: "Rede 115 — 1 rolo / 50 m² (+10% desperdício)",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 1.1 / 50)) },

    { productKey: "REABILITA_CAL_AC_AC01_NATURAL_SACO_25_KG_MONTIJO_PATAIAS",
      skip: ({ becorkProd }) => becorkProd === "floor",
      base: "Acabamento Cal AC — 2,4 kg/m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 2.4 / 25)) },

    { productKey: "REABILITA_CAL_AC_FINO_AC01_NATURAL_SACO_18_KG_MONTIJO_PATAIAS",
      skip: ({ becorkProd, becorkCalAcFino }) => becorkProd === "floor" || !becorkCalAcFino,
      base: "Cal AC Fino — 1,5 kg/m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 1.5 / 18)) },

    { productKey: "REABILITA_RR_20_SACO_25_KG_MONTIJO_PATAIAS",
      skip: ({ becorkProd, becorkRr20 }) => becorkProd !== "render" || !becorkRr20,
      base: "Reabilita RR20 — 3 kg/m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 3.0 / 25)) },

    { productKey: "B_REPARA_PROTECAO_AD_40_JERRICAN_5_LT_MACEIRA",
      skip: ({ becorkProd, becorkTopCoat }) => becorkProd === "floor" || becorkTopCoat !== "ad40",
      base: "Pintura AD40 — 1 lt / 2,5 m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area / 12.5)) },

    { productKey: PRODUCT_KEYS.ISOVIT_AD25,
      skip: ({ becorkProd, becorkTopCoat }) => becorkProd === "floor" || becorkTopCoat !== "ad25_revsp",
      base: "Primário AD25 — 1 balde / 75 m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area / 75)) },

    { productKey: PRODUCT_KEYS.ISOVIT_REV_SP,
      skip: ({ becorkProd, becorkTopCoat }) => becorkProd === "floor" || becorkTopCoat !== "ad25_revsp",
      base: "Rev SP — 1 balde / 15 m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area / 15)) },
  ],

  adhere: [
    /* Cola cerâmica — com suporte a colagem dupla */
    { getProductKey: ({ adhereProd }) => ADHERE_COLA_KEYS[adhereProd] || ADHERE_COLA_KEYS.ci10_cinza,
      base: ({ adhereDoubleBond }) => adhereDoubleBond ? "Cola — 4 kg/m² × 2 (colagem dupla)" : "Cola — 4 kg/m²",
      qty: ({ area, adhereDoubleBond }) => {
        const base = Math.max(1, Math.ceil(area * 4 / 25));
        return adhereDoubleBond ? base * 2 : base;
      } },

    /* Betumação de juntas — fórmula Ct = 0,18·L·H·((A+B)/(A·B)) */
    { getProductKey: ({ adhereCor }) => ADHERE_COR_KEYS[adhereCor] || null,
      skip: ({ adhereCor }) => !adhereCor || adhereCor === "sem",
      base: ({ adhereLargJunta, adhereAltPeca, adhereCompPeca, adhereLargPeca }) => {
        const L = adhereLargJunta || 2, H = adhereAltPeca || 10;
        const A = adhereCompPeca  || 30, B = adhereLargPeca || 30;
        const Ct = 0.18 * L * H * ((A + B) / (A * B));
        return `Betumação — ${Ct.toFixed(3)} kg/m² (L=${L}mm, H=${H}mm, A=${A}cm, B=${B}cm)`;
      },
      qty: ({ area, adhereLargJunta, adhereAltPeca, adhereCompPeca, adhereLargPeca }) => {
        const L = adhereLargJunta || 2, H = adhereAltPeca || 10;
        const A = adhereCompPeca  || 30, B = adhereLargPeca || 30;
        const Ct = 0.18 * L * H * ((A + B) / (A * B));
        return Math.max(1, Math.ceil(area * Ct / 5));
      } },
  ],

  hidrostop: [
    { getProductKey: ({ hidrostopProd }) => HIDROSTOP_PROD_KEYS[hidrostopProd] || HIDROSTOP_PROD_KEYS.flex,
      base: ({ hidrostopProd }) => {
        const s = HIDROSTOP_PROD_SPEC[hidrostopProd] || HIDROSTOP_PROD_SPEC.flex;
        return `Impermeabilização — ${s.kg} kg/m² (2 demãos)`;
      },
      qty: ({ area, hidrostopProd }) => {
        const s = HIDROSTOP_PROD_SPEC[hidrostopProd] || HIDROSTOP_PROD_SPEC.flex;
        return Math.max(1, Math.ceil(area * s.kg / s.pack));
      } },

    { productKey: "HIDROSTOP_BANDA_ROLO_50_M_MACEIRA",
      skip: ({ hidrostopPerimetro }) => !hidrostopPerimetro || hidrostopPerimetro <= 0,
      base: "Banda — 1 rolo / 50 ml",
      qty: ({ hidrostopPerimetro }) => Math.max(1, Math.ceil(hidrostopPerimetro / 50)) },
  ],

  reabilita: [
    /* Consolidação — com espessura configurável (ref. 15 mm) */
    { getProductKey: ({ reabConsolidacao }) => REAB_CONSOL_KEYS[reabConsolidacao] || null,
      skip: ({ reabConsolidacao }) => !reabConsolidacao || reabConsolidacao === "sem",
      base: ({ reabConsolidacao, reabConsolidacaoEsp }) => {
        const kg  = REAB_CONSOL_KG[reabConsolidacao] || 18;
        const esp = reabConsolidacaoEsp || 15;
        return `Consolidação — ${(kg * esp / 15).toFixed(1)} kg/m² (${esp} mm)`;
      },
      qty: ({ area, reabConsolidacao, reabConsolidacaoEsp }) => {
        const kg  = REAB_CONSOL_KG[reabConsolidacao] || 18;
        const esp = reabConsolidacaoEsp || 15;
        return Math.max(1, Math.ceil(area * kg * esp / (15 * 25)));
      } },

    /* Reboco — com espessura configurável (ref. 15 mm) */
    { getProductKey: ({ reabReboco }) => REAB_REBOCO_KEYS[reabReboco] || null,
      skip: ({ reabReboco }) => !reabReboco || reabReboco === "sem",
      base: ({ reabReboco, reabRebocoEsp }) => {
        const kg  = REAB_REBOCO_KG[reabReboco] || 12;
        const esp = reabRebocoEsp || 15;
        return `Reboco — ${(kg * esp / 15).toFixed(1)} kg/m² (${esp} mm)`;
      },
      qty: ({ area, reabReboco, reabRebocoEsp }) => {
        const kg  = REAB_REBOCO_KG[reabReboco] || 12;
        const esp = reabRebocoEsp || 15;
        return Math.max(1, Math.ceil(area * kg * esp / (15 * 25)));
      } },

    /* 1.º Barramento de acabamento */
    { getProductKey: ({ reabAcabamento }) => REAB_ACAB_KEYS[reabAcabamento] || null,
      skip: ({ reabAcabamento }) => !reabAcabamento || reabAcabamento === "sem",
      base: ({ reabAcabamento }) => {
        const s = REAB_ACAB_SPEC[reabAcabamento];
        return s ? `1.º Barramento — ${s.kg} kg/m²` : "1.º Barramento";
      },
      qty: ({ area, reabAcabamento }) => {
        const s = REAB_ACAB_SPEC[reabAcabamento];
        return s ? Math.max(1, Math.ceil(area * s.kg / s.pack)) : 0;
      } },

    /* 2.º Barramento de acabamento (opcional) */
    { getProductKey: ({ reabAcabamento2 }) => REAB_ACAB_KEYS[reabAcabamento2] || null,
      skip: ({ reabAcabamento2 }) => !reabAcabamento2 || reabAcabamento2 === "sem",
      base: ({ reabAcabamento2 }) => {
        const s = REAB_ACAB_SPEC[reabAcabamento2];
        return s ? `2.º Barramento — ${s.kg} kg/m²` : "2.º Barramento";
      },
      qty: ({ area, reabAcabamento2 }) => {
        const s = REAB_ACAB_SPEC[reabAcabamento2];
        return s ? Math.max(1, Math.ceil(area * s.kg / s.pack)) : 0;
      } },

    /* Esquema de pintura */
    { getProductKey: ({ reabPintura }) => {
        if (reabPintura === "rev_sp")  return PRODUCT_KEYS.ISOVIT_REV_SP;
        if (reabPintura === "rev_sls") return PRODUCT_KEYS.ISOVIT_REV_SLS;
        if (reabPintura === "ad40")    return "B_REPARA_PROTECAO_AD_40_JERRICAN_5_LT_MACEIRA";
        return null;
      },
      skip: ({ reabPintura }) => !reabPintura || reabPintura === "sem",
      base: ({ reabPintura }) => {
        if (reabPintura === "rev_sp")  return "ISOVIT REV SP — 1 balde / 15 m²";
        if (reabPintura === "rev_sls") return "ISOVIT REV SLS — 1 balde / 25 m²";
        if (reabPintura === "ad40")    return "B-REPARA AD40 — 1 lt / 2,5 m²";
        return "Pintura";
      },
      qty: ({ area, reabPintura }) => {
        if (reabPintura === "rev_sp")  return Math.max(1, Math.ceil(area / 15));
        if (reabPintura === "rev_sls") return Math.max(1, Math.ceil(area / 25));
        if (reabPintura === "ad40")    return Math.max(1, Math.ceil(area / 12.5));
        return 0;
      } },

    /* Redes — checkboxes independentes (+10% desperdício) */
    { productKey: "REABILITA_REDE_AR_160_60_M2_1_ROLO_MACEIRA",
      skip: ({ reabRedeAr160 }) => !reabRedeAr160,
      base: "REABILITA REDE AR 160 — 1 rolo / 60 m² (+10%)",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 1.1 / 60)) },

    { productKey: PRODUCT_KEYS.ISOVIT_REDE160,
      skip: ({ reabRedeIsovit160 }) => !reabRedeIsovit160,
      base: "ISOVIT REDE 160 — 1 rolo / 50 m² (+10%)",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 1.1 / 50)) },

    { productKey: "REDUR_REDE_115_50_M2_1_ROLO_MACEIRA",
      skip: ({ reabRedeRedur115 }) => !reabRedeRedur115,
      base: "REDUR REDE 115 — 1 rolo / 50 m² (+10%)",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 1.1 / 50)) },

    { productKey: "REABILITA_REDE_CARBON_200_200_97_5_M2_1_ROLO_MACEIRA",
      skip: ({ reabRedeCarbon200 }) => !reabRedeCarbon200,
      base: "REDE CARBON 200/200 — 1 rolo / 97,5 m² (+10%)",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 1.1 / 97.5)) },

    { productKey: "REABILITA_REDE_CARBON_242_50_M2_1_ROLO_MACEIRA",
      skip: ({ reabRedeCarbon242 }) => !reabRedeCarbon242,
      base: "REDE CARBON 242 — 1 rolo / 50 m² (+10%)",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 1.1 / 50)) },
  ],

  isovit: [
    { productKey: PRODUCT_KEYS.ISOVIT_AD25,
      base: "Primário — 1 balde / 75 m²",
      qty: ({ area }) => Math.max(1, Math.ceil(area / 75)) },

    /* Painel de isolamento — tipo e espessura */
    { getProductKey: ({ isovitPanel, isovitEspessura }) => {
        const pkeys = ISOVIT_PANEL_KEYS[isovitPanel];
        return pkeys ? (pkeys[isovitEspessura] || null) : null;
      },
      skip: ({ isovitPanel }) => !isovitPanel,
      base: ({ isovitPanel, isovitEspessura }) => `Painel ${isovitPanel?.toUpperCase().replace('_',' ')} ${isovitEspessura} mm`,
      qty: ({ area, isovitPanel, isovitEspessura }) => {
        const cover = (ISOVIT_PANEL_COVER[isovitPanel] || {})[isovitEspessura] || 1;
        return Math.max(1, Math.ceil(area / cover));
      } },

    /* Argamassa de colagem */
    { getProductKey: ({ isovitColagem }) => ISOVIT_COLAGEM_KEYS[isovitColagem] || ISOVIT_COLAGEM_KEYS.fibra,
      base: ({ isovitColagem }) => {
        const s = ISOVIT_COLAGEM_SPEC[isovitColagem] || ISOVIT_COLAGEM_SPEC.fibra;
        return `Argamassa de colagem — ${s.kg} kg/m²`;
      },
      qty: ({ area, isovitColagem }) => {
        const s = ISOVIT_COLAGEM_SPEC[isovitColagem] || ISOVIT_COLAGEM_SPEC.fibra;
        return Math.max(1, Math.ceil(area * s.kg / s.pack));
      } },

    /* Argamassa de regularização (barramento) — sempre com REDE 160 */
    { getProductKey: ({ isovitBarramento }) => ISOVIT_COLAGEM_KEYS[isovitBarramento] || ISOVIT_COLAGEM_KEYS.fibra,
      base: ({ isovitBarramento }) => {
        const s = ISOVIT_COLAGEM_SPEC[isovitBarramento] || ISOVIT_COLAGEM_SPEC.fibra;
        return `Argamassa de regularização — ${s.kg} kg/m²`;
      },
      qty: ({ area, isovitBarramento }) => {
        const s = ISOVIT_COLAGEM_SPEC[isovitBarramento] || ISOVIT_COLAGEM_SPEC.fibra;
        return Math.max(1, Math.ceil(area * s.kg / s.pack));
      } },

    /* REDE 160 — sempre incluída com barramento (+10% desperdício) */
    { productKey: PRODUCT_KEYS.ISOVIT_REDE160,
      base: "Rede 160 — 1 rolo / 50 m² (+10% desperdício)",
      qty: ({ area }) => Math.max(1, Math.ceil(area * 1.1 / 50)) },

    { productKey: PRODUCT_KEYS.ISOVIT_BUCHA90,
      base: "Fixação — 6 buchas/m²",
      qty: ({ area }) => Math.max(1, Math.ceil((area * 6) / 200)) },

    { getProductKey: ({ isovitEspessura }) => isovitArranqueKey(Number(isovitEspessura) || 60),
      base: "Perfil de arranque (Pack 20 un × 2,5 m)",
      qty: ({ area }) => Math.max(1, Math.ceil(4 * Math.sqrt(area) / (20 * 2.5))) },

    { productKey: PRODUCT_KEYS.ISOVIT_ACABAMENTO,
      base: "Perfil de canto (Pack 50 un × 2,5 m)",
      qty: ({ isovitAcabML }) => Math.max(0, Math.ceil(isovitAcabML / (50 * 2.5))) },

    { getProductKey: ({ isovitAcabamento }) => ISOVIT_ACAB_KEYS[isovitAcabamento] || null,
      skip: ({ isovitAcabamento }) => !isovitAcabamento || isovitAcabamento === "sem",
      base: "Acabamento",
      qty: ({ area, isovitAcabamento }) => {
        const cover = ISOVIT_ACAB_COVER[isovitAcabamento] || 25;
        return Math.max(1, Math.ceil(area / cover));
      } },
  ],
};
