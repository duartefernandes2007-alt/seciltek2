/* Seciltek – Orçamentação Profissional | app.js v8 */
import { materialRules, ISOVIT_PANEL_THICKNESSES } from "./rules.js";

/* ============================================================
   UTILITÁRIOS
   ============================================================ */
const fmt      = (v) => (Number(v) || 0).toLocaleString("pt-PT", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " €";
const fmtNum   = (v) => (Number(v) || 0).toLocaleString("pt-PT", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtM2    = (v) => fmtNum(v) + " m²";
const fmtML    = (v) => fmtNum(v) + " m";
const qs       = (id) => document.getElementById(id);
const number   = (id) => Math.max(0, Number(qs(id)?.value || 0));
const fmtEurM2 = (v) => fmtNum(v) + " €/m²";
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

let currentSystem = "microart";

/* ============================================================
   SYSTEM LABEL HELPER
   ============================================================ */
function getSysLabel() {
  const names = { microart: "Microart", isodur: "Isodur", redur: "Redur", becork: "Becork", adhere: "Adhere", hidrostop: "Hidrostop", reabilita: "Reabilita", isovit: "Isovit" };
  let lbl = names[currentSystem] || currentSystem;
  if (currentSystem === "microart") {
    const m = { parede: "Parede", pavimento: "Pavimento", ceramico: "Cerâmico", outros: "Outros" };
    lbl += ` ${m[qs("suporte")?.value] || "Parede"}`;
  } else if (currentSystem === "isodur") {
    const m = { areado: "Areado", liso_ext: "Liso Ext", liso_int: "Liso Int", acrilico: "Acrílico", cal_ac: "Cal AC" };
    lbl += ` ${m[qs("isodurSistema")?.value] || ""} · ${qs("espessura")?.value || 60} mm`;
  } else if (currentSystem === "redur") {
    lbl += ` ${qs("redurTipo")?.value === "interior" ? "Interior" : "Exterior"} · ${qs("redurEspessura")?.value || 15} mm`;
  } else if (currentSystem === "becork") {
    const m = { lime: "Lime", render: "Render", floor: "Floor" };
    lbl += ` ${m[qs("becorkProd")?.value] || ""} · ${qs("becorkEspessura")?.value || 20} mm`;
  } else if (currentSystem === "hidrostop") {
    const m = { flex: "Flex", elastico: "Elástico", elasticofibras: "Elástico Fibras", resist: "Resist" };
    lbl += ` ${m[qs("hidrostopProd")?.value] || ""}`;
  } else if (currentSystem === "isovit") {
    const panelLabels = { eps100: "EPS100", eps150: "EPS150", eps80grafite: "EPS80G", icb: "ICB", icb_md: "ICB MD", icb_md_wave: "ICB Wave", wf: "WF", mw_fkd_s: "MW FKD-S" };
    const panel = panelLabels[qs("isovitPanel")?.value] || "";
    lbl += ` ${panel} · ${qs("isovitEspessura")?.value || 60} mm`;
  }
  return lbl.trim();
}

/* ============================================================
   CATÁLOGO
   ============================================================ */
function catalogItem(key) {
  const item = window.SECILTEK_PRICE_INDEX?.[key];
  if (!item) console.warn("Produto não encontrado no catálogo:", key);
  return item || { produto: key, unidade: "—", precoPalete: 0, precoAvulso: null, local: "" };
}

function priceFor(item) {
  const product = catalogItem(item.productKey);
  const preferAvulso = qs("tipoPreco")?.value === "avulso";
  if (preferAvulso && Number(product.precoAvulso) > 0) return Number(product.precoAvulso);
  return Number(product.precoPalete || product.precoAvulso || 0);
}

/* ============================================================
   CÁLCULO DE MATERIAIS
   ============================================================ */
function areaTotal() {
  return currentSystem === "microart"
    ? number("area1") + number("area2") + number("area3")
    : number("area1");
}

function calculateMaterials() {
  const rawArea = areaTotal();
  const waste   = Math.max(0, number("desperdicio")) / 100;

  const context = {
    area:                rawArea * (1 + waste),
    espessura:           number("espessura") || 60,
    acabamento:          number("acabamento"),
    suporte:             qs("suporte")?.value            || "parede",
    corMc01:             qs("corMc01")?.value            || "base",
    microartRede90:      qs("microartRede90")?.checked   || false,
    redurTipo:           qs("redurTipo")?.value          || "exterior",
    redurReboco:         qs("redurReboco")?.value        || "irp_ext",
    redurAcabamento:     qs("redurAcabamento")?.value    || "pk06",
    redurPromotor:       qs("redurPromotor")?.value      || "sem",
    redurEspessura:      number("redurEspessura") || 15,
    redurRede:           qs("redurRede")?.checked        || false,
    becorkProd:          qs("becorkProd")?.value         || "lime",
    becorkPromotor:      qs("becorkPromotor")?.value     || "sem",
    becorkEspessura:     number("becorkEspessura") || 20,
    becorkRede:          qs("becorkRede")?.checked       || false,
    becorkCalAcFino:     qs("becorkCalAcFino")?.checked  || false,
    becorkRr20:          qs("becorkRr20")?.checked       || false,
    becorkTopCoat:       qs("becorkTopCoat")?.value      || "sem",
    adhereProd:          qs("adhereProd")?.value         || "ci10_cinza",
    adhereCor:           qs("adhereCor")?.value          || "sem",
    adhereDoubleBond:    qs("adhereDoubleBond")?.checked || false,
    adhereLargJunta:     number("adhereLargJunta") || 2,
    adhereAltPeca:       number("adhereAltPeca")  || 10,
    adhereCompPeca:      number("adhereCompPeca") || 30,
    adhereLargPeca:      number("adhereLargPeca") || 30,
    hidrostopProd:       qs("hidrostopProd")?.value      || "flex",
    hidrostopPerimetro:  number("hidrostopPerimetro"),
    reabConsolidacao:    qs("reabConsolidacao")?.value   || "sem",
    reabConsolidacaoEsp: number("reabConsolidacaoEsp") || 15,
    reabReboco:          qs("reabReboco")?.value         || "cal_rb",
    reabRebocoEsp:       number("reabRebocoEsp") || 15,
    reabAcabamento:      qs("reabAcabamento")?.value     || "cal_ac",
    reabAcabamento2:     qs("reabAcabamento2")?.value    || "sem",
    reabPintura:         qs("reabPintura")?.value        || "sem",
    reabRedeAr160:       qs("reabRedeAr160")?.checked    || false,
    reabRedeIsovit160:   qs("reabRedeIsovit160")?.checked || false,
    reabRedeRedur115:    qs("reabRedeRedur115")?.checked  || false,
    reabRedeCarbon200:   qs("reabRedeCarbon200")?.checked || false,
    reabRedeCarbon242:   qs("reabRedeCarbon242")?.checked || false,
    isodurSistema:       qs("isodurSistema")?.value      || "areado",
    isodurGranulo:       qs("isodurGranulo")?.value      || "07",
    isodurCalAcFino:     qs("isodurCalAcFino")?.checked  || false,
    isodurPromotor:      qs("isodurPromotor")?.value     || "sem",
    isodurTopCoat:       qs("isodurTopCoat")?.value      || "sem",
    isovitPanel:         qs("isovitPanel")?.value        || "eps100",
    isovitColagem:       qs("isovitColagem")?.value      || "fibra",
    isovitBarramento:    qs("isovitBarramento")?.value   || "fibra",
    isovitAcabamento:    qs("isovitAcabamento")?.value   || "rev_a",
    isovitEspessura:     number("isovitEspessura") || 60,
    isovitAcabML:        number("isovitAcabML"),
  };

  const body = qs("materialsBody");

  if (rawArea === 0) {
    body.innerHTML = `<tr><td colspan="6" class="materials-empty">Introduza a área para calcular os materiais necessários.</td></tr>`;
    if (qs("tableTotalMateriais")) qs("tableTotalMateriais").textContent = fmt(0);
    return 0;
  }

  const rules = materialRules[currentSystem].filter((item) => {
    if (item.wallOnly     && context.suporte   !== "parede")   return false;
    if (item.exteriorOnly && context.redurTipo !== "exterior") return false;
    if (item.skip         && item.skip(context))               return false;
    return true;
  });

  const rows = rules.map((item) => {
    const resolvedKey = item.getProductKey ? item.getProductKey(context) : item.productKey;
    if (!resolvedKey) return null;
    const resolvedItem = { ...item, productKey: resolvedKey };
    const product = catalogItem(resolvedKey);
    const qty     = Number(resolvedItem.qty(context) || 0);
    const price   = priceFor(resolvedItem);
    const base    = typeof resolvedItem.base === "function" ? resolvedItem.base(context) : resolvedItem.base;
    return { product, name: product.produto, unit: product.unidade, base, qty, price, total: qty * price };
  }).filter(Boolean);

  body.innerHTML = rows.map((r) => `
    <tr>
      <td><span class="mat-name">${r.name}</span><span class="mat-local">${r.product.local || ""}</span></td>
      <td><span class="mat-base">${r.base}</span></td>
      <td>${r.unit}</td>
      <td class="num mat-qty">${fmtNum(r.qty)}</td>
      <td class="num mat-price">${fmt(r.price)}</td>
      <td class="num line-total">${fmt(r.total)}</td>
    </tr>`).join("");

  const total = rows.reduce((s, r) => s + r.total, 0);

  if (qs("tableTotalMateriais")) qs("tableTotalMateriais").textContent = fmt(total);
  if (qs("catalogSource")) {
    const tipo      = qs("tipoPreco")?.value === "avulso" ? "Preço avulso quando disponível" : "Preço em palete";
    const wasteTxt  = waste > 0 ? ` · +${Math.round(waste * 100)}% desperdício incluído` : "";
    qs("catalogSource").textContent = `${window.SECILTEK_CATALOG_SOURCE || "Tabela de preços Seciltek"} · ${tipo} · Valores sem IVA${wasteTxt}.`;
  }
  return total;
}

/* ============================================================
   CALCULATE — atualiza todos os KPIs e o resumo
   ============================================================ */
let lastCalc = { area: 0, sale: 0, priceM2: 0, matNet: 0 };

function calculate() {
  const area = areaTotal();

  qs("areaTotal").textContent = fmtM2(area);
  if (qs("espessuraTotal"))       qs("espessuraTotal").textContent     = (qs("espessura")?.value || "60") + " mm";
  if (qs("acabamentoTotal"))      qs("acabamentoTotal").textContent    = fmtML(number("acabamento"));
  if (qs("redurRebocoLabel"))     qs("redurRebocoLabel").textContent   = qs("redurReboco")?.selectedOptions[0]?.text || "IRP Ext.";
  if (qs("becorkProdLabel"))      qs("becorkProdLabel").textContent    = qs("becorkProd")?.selectedOptions[0]?.text?.split(" ")[1] || "Lime";
  if (qs("hidrostopProdLabel"))   qs("hidrostopProdLabel").textContent = qs("hidrostopProd")?.selectedOptions[0]?.text?.split(" ").slice(1).join(" ") || "Flex";
  if (qs("isovitEspessuraLabel")) qs("isovitEspessuraLabel").textContent = (qs("isovitEspessura")?.value || "60") + " mm";

  const materials = calculateMaterials();
  const discount  = Math.min(Math.max(number("desconto"), 0), 100) / 100;
  const matNet    = materials * (1 - discount);
  const labor     = area * number("maoObra");
  const transport = number("transporte");
  const base      = matNet + labor + transport;
  const margin    = base * (number("margem") / 100);
  const sale      = base + margin;
  const priceM2   = area > 0 ? sale / area : 0;

  lastCalc = { area, sale, priceM2, matNet };

  qs("sumMateriais").textContent  = fmt(matNet);
  qs("sumMaoObra").textContent    = fmt(labor);
  qs("sumTransporte").textContent = fmt(transport);
  qs("sumMargem").textContent     = fmt(margin);
  qs("sumVenda").textContent      = fmt(sale);
  qs("sumPrecoM2").textContent    = area > 0 ? fmtEurM2(priceM2) : "— €/m²";

  qs("heroTotal").textContent = fmt(sale);
  qs("heroM2").textContent    = area > 0 ? fmtEurM2(priceM2) : "— €/m²";
  qs("kpiArea").textContent   = fmtM2(area);

  if (qs("sidebarTotal")) qs("sidebarTotal").textContent = fmt(sale);
  if (qs("sidebarM2"))    qs("sidebarM2").textContent    = area > 0 ? fmtEurM2(priceM2) : "— €/m²";
  if (qs("mobileTotal"))  qs("mobileTotal").textContent  = fmt(sale);

  const cliente = qs("cliente").value.trim() || "Cliente";
  const obra    = qs("obra").value.trim()    || "obra sem referência";
  const local   = qs("local").value.trim();

  qs("resumoTitulo").textContent = `${getSysLabel()} — ${cliente}`;
  qs("resumoInfo").textContent   = `${obra}${local ? " · " + local : ""} · Área total: ${fmtM2(area)}. Valores sem IVA.`;
}

/* ============================================================
   LOAD SYSTEM
   ============================================================ */
function loadSystem(system) {
  currentSystem = system;
  const multiArea = system === "microart";

  document.querySelectorAll(".sys-btn").forEach((btn) => {
    const active = btn.dataset.system === system;
    btn.classList.toggle("active", active);
    btn.setAttribute("aria-selected", String(active));
  });
  document.querySelectorAll(".nav-item[data-step='2']").forEach((el) =>
    el.classList.toggle("active", true));

  document.querySelectorAll(".multi-area").forEach((el) =>
    el.classList.toggle("hidden", !multiArea));

  const systemClasses = [
    "microart-area", "redur-only", "isodur-only",
    "becork-only", "adhere-only", "hidrostop-only", "reabilita-only", "isovit-only",
  ];
  systemClasses.forEach((cls) => {
    document.querySelectorAll(`.${cls}`).forEach((el) => el.classList.add("hidden"));
  });

  const activeClass = {
    microart:  "microart-area",  isodur: "isodur-only", redur: "redur-only",
    becork:    "becork-only",    adhere: "adhere-only", hidrostop: "hidrostop-only",
    reabilita: "reabilita-only", isovit: "isovit-only",
  }[system];

  if (activeClass) {
    document.querySelectorAll(`.${activeClass}`).forEach((el) => el.classList.remove("hidden"));
  }

  if (system === "isodur")    updateIsodurFields();
  if (system === "becork")    updateBecorkFields();
  if (system === "adhere")    updateAdhereFields();
  if (system === "reabilita") updateReabilitaFields();
  if (system === "isovit")    updateIsovitFields();

  const sysNames = {
    microart: "Microart", isodur: "Isodur", redur: "Redur", becork: "Becork",
    adhere: "Adhere", hidrostop: "Hidrostop", reabilita: "Reabilita", isovit: "Isovit",
  };
  const sysName = sysNames[system] || system;
  qs("systemName").textContent = sysName;
  qs("kpiSys").textContent     = sysName;

  const labelEl = qs("area1Label")?.querySelector("label");
  if (labelEl) labelEl.textContent = multiArea ? "Ambiente 1 / Área principal (m²)" : "Área principal (m²)";

  calculate();
}

/* ============================================================
   CONDITIONAL FIELD VISIBILITY
   ============================================================ */
function updateIsodurFields() {
  const sistema = qs("isodurSistema")?.value || "areado";
  qs("isodurGranuloGroup")?.classList.toggle("hidden", sistema !== "acrilico");
  qs("isodurCalAcFinoGroup")?.classList.toggle("hidden", sistema !== "cal_ac");
}

function updateAdhereFields() {
  const hasBet = (qs("adhereCor")?.value || "sem") !== "sem";
  document.querySelectorAll(".adhere-bet-only").forEach((el) =>
    el.classList.toggle("hidden", !hasBet));
}

function updateReabilitaFields() {
  const hasConsol = (qs("reabConsolidacao")?.value || "sem") !== "sem";
  qs("reabConsolidacaoEspGroup")?.classList.toggle("hidden", !hasConsol);
  const hasReboco = (qs("reabReboco")?.value || "sem") !== "sem";
  qs("reabRebocoEspGroup")?.classList.toggle("hidden", !hasReboco);
}

function updateIsovitFields() {
  const panel = qs("isovitPanel")?.value || "eps100";
  const thicknesses = ISOVIT_PANEL_THICKNESSES[panel] || [60];
  const sel = qs("isovitEspessura");
  if (!sel) return;
  const cur = Number(sel.value);
  sel.innerHTML = "";
  const midIdx = Math.floor(thicknesses.length / 2);
  const defVal = thicknesses.includes(cur) ? cur : thicknesses[midIdx];
  thicknesses.forEach(mm => {
    const opt = document.createElement("option");
    opt.value = mm;
    opt.textContent = `${mm} mm`;
    if (mm === defVal) opt.selected = true;
    sel.appendChild(opt);
  });
}

const BECORK_ESP = {
  lime:   { min: 20, max: 60,  step: 5  },
  render: { min: 10, max: 40,  step: 5  },
  floor:  { min: 60, max: 120, step: 10 },
};

function updateBecorkFields() {
  const prod = qs("becorkProd")?.value || "lime";
  const { min, max, step } = BECORK_ESP[prod] || BECORK_ESP.lime;
  const sel = qs("becorkEspessura");
  if (sel) {
    const cur = Number(sel.value);
    sel.innerHTML = "";
    for (let v = min; v <= max; v += step) {
      const opt = document.createElement("option");
      opt.value = v;
      opt.textContent = `${v} mm`;
      if (v === (cur >= min && cur <= max ? cur : min)) opt.selected = true;
      sel.appendChild(opt);
    }
    if (!sel.value) sel.value = min;
  }
  qs("becorkRr20Group")?.classList.toggle("hidden", prod !== "render");
  qs("becorkTopCoatGroup")?.classList.toggle("hidden", prod === "floor");
}

/* ============================================================
   RESET
   ============================================================ */
function resetAll() {
  document.querySelectorAll("input").forEach((el) => {
    if (el.id === "validade")        { el.value = "30 dias"; return; }
    if (el.id === "desperdicio")     { el.value = "10"; return; }
    if (el.id === "adhereLargJunta") { el.value = "2"; return; }
    if (el.id === "adhereAltPeca")   { el.value = "10"; return; }
    if (el.id === "adhereCompPeca")  { el.value = "30"; return; }
    if (el.id === "adhereLargPeca")  { el.value = "30"; return; }
    el.value = el.type === "number" ? "0" : "";
  });
  const selectDefaults = {
    tipoPreco: "palete", espessura: "60", suporte: "parede", corMc01: "base",
    isodurPromotor: "sem", isodurSistema: "areado", isodurGranulo: "07", isodurTopCoat: "sem",
    redurPromotor: "sem", redurTipo: "exterior", redurReboco: "irp_ext",
    redurEspessura: "15", redurAcabamento: "pk06",
    becorkPromotor: "sem", becorkProd: "lime", becorkEspessura: "20", becorkTopCoat: "sem",
    adhereProd: "ci10_cinza", adhereCor: "sem", hidrostopProd: "flex",
    reabConsolidacao: "sem", reabReboco: "cal_rb", reabAcabamento: "cal_ac",
    reabAcabamento2: "sem", reabPintura: "sem",
    reabConsolidacaoEsp: "15", reabRebocoEsp: "15",
    isovitPanel: "eps100", isovitColagem: "fibra", isovitBarramento: "fibra",
    isovitAcabamento: "rev_a",
  };
  Object.entries(selectDefaults).forEach(([id, val]) => { const el = qs(id); if (el) el.value = val; });
  ["isodurCalAcFino", "redurRede", "becorkRede", "becorkCalAcFino", "becorkRr20",
   "microartRede90", "adhereDoubleBond",
   "reabRedeAr160", "reabRedeIsovit160", "reabRedeRedur115", "reabRedeCarbon200", "reabRedeCarbon242"
  ].forEach((id) => { const el = qs(id); if (el) el.checked = false; });
  updateBecorkFields();
  updateIsodurFields();
  updateIsovitFields();
  updateAdhereFields();
  updateReabilitaFields();
  loadSystem("microart");
}

/* ============================================================
   COMPARADOR DE SISTEMAS
   ============================================================ */
const comparisons = [];

function addToComparison() {
  if (lastCalc.area === 0) { showToast("Introduza uma área antes de comparar."); return; }
  const snap = {
    id:      Date.now(),
    label:   getSysLabel(),
    area:    lastCalc.area,
    sale:    lastCalc.sale,
    priceM2: lastCalc.priceM2,
    matNet:  lastCalc.matNet,
  };
  if (comparisons.length >= 3) comparisons.shift();
  comparisons.push(snap);
  renderComparator();
  showToast(`"${snap.label}" adicionado ao comparador.`);
}

function renderComparator() {
  const sec = qs("comparatorSection");
  if (!sec) return;
  if (!comparisons.length) { sec.classList.add("hidden"); return; }
  sec.classList.remove("hidden");

  const activeSales  = comparisons.filter(c => c.priceM2 > 0).map(c => c.priceM2);
  const best = activeSales.length ? Math.min(...activeSales) : -1;

  sec.querySelector(".cmp-grid").innerHTML = comparisons.map(c => {
    const isBest = c.priceM2 > 0 && c.priceM2 === best;
    return `
      <div class="cmp-card${isBest ? " cmp-best" : ""}">
        ${isBest ? '<span class="cmp-badge">Mais económico</span>' : ""}
        <button class="cmp-del" data-id="${c.id}" title="Remover">×</button>
        <div class="cmp-sys-name">${c.label}</div>
        <div class="cmp-area">${fmtM2(c.area)}</div>
        <div class="cmp-row"><span>Materiais</span><strong>${fmt(c.matNet)}</strong></div>
        <div class="cmp-row cmp-total-row"><span>Total (sem IVA)</span><strong>${fmt(c.sale)}</strong></div>
        <div class="cmp-m2">${c.area > 0 ? fmtEurM2(c.priceM2) : "—"}</div>
      </div>`;
  }).join("");
}

/* ============================================================
   PDF — TEMPLATE DE IMPRESSÃO
   ============================================================ */
function buildPrintProposal() {
  const cliente  = qs("cliente").value.trim() || "—";
  const obra     = qs("obra").value.trim()    || "—";
  const local    = qs("local").value.trim()   || "—";
  const cor      = qs("cor").value.trim()     || "—";
  const today    = new Date().toLocaleDateString("pt-PT", { day: "2-digit", month: "2-digit", year: "numeric" });
  const sysDetail = getSysLabel();
  const area     = fmtM2(areaTotal());
  const matHTML  = qs("materialsBody").innerHTML;
  const totalMat = qs("tableTotalMateriais").textContent;
  const desconto = number("desconto");
  const hasLabor  = number("maoObra") > 0;
  const hasTransp = number("transporte") > 0;
  const hasMargem = number("margem") > 0;

  qs("printProposal").innerHTML = `
    <div class="pp-header">
      <img src="assets/seciltek-logo.png" class="pp-logo" alt="Seciltek" />
      <div class="pp-header-right">
        <div class="pp-doc-type">Proposta Comercial</div>
        <div class="pp-doc-sub">Materiais de Construção · seciltek.pt</div>
        <div class="pp-doc-date">Data de emissão: ${today}</div>
      </div>
    </div>

    <div class="pp-client-grid">
      <div class="pp-cell"><div class="pp-cell-label">Cliente</div><div class="pp-cell-val">${cliente}</div></div>
      <div class="pp-cell"><div class="pp-cell-label">Obra / Referência</div><div class="pp-cell-val">${obra}</div></div>
      <div class="pp-cell"><div class="pp-cell-label">Localidade</div><div class="pp-cell-val">${local}</div></div>
      <div class="pp-cell"><div class="pp-cell-label">Sistema</div><div class="pp-cell-val">${sysDetail}</div></div>
      <div class="pp-cell"><div class="pp-cell-label">Área total</div><div class="pp-cell-val">${area}</div></div>
      <div class="pp-cell"><div class="pp-cell-label">Cor / Acabamento</div><div class="pp-cell-val">${cor}</div></div>
    </div>

    <div class="pp-section-title">Materiais necessários</div>
    <table class="pp-mat-table">
      <thead>
        <tr>
          <th>Material</th><th>Base de cálculo</th><th>Un.</th>
          <th class="num">Qtd.</th><th class="num">Preço unit.</th><th class="num">Total</th>
        </tr>
      </thead>
      <tbody>${matHTML}</tbody>
      <tfoot>
        <tr>
          <td colspan="5">Total materiais (antes de desconto)</td>
          <td class="num">${totalMat}</td>
        </tr>
      </tfoot>
    </table>

    <div class="pp-section-title">Resumo comercial</div>
    <div class="pp-comm-grid">
      <div class="pp-comm-row">
        <span>Materiais${desconto > 0 ? ` (desconto ${desconto}%)` : ""}</span>
        <strong>${qs("sumMateriais").textContent}</strong>
      </div>
      ${hasLabor  ? `<div class="pp-comm-row"><span>Mão de obra</span><strong>${qs("sumMaoObra").textContent}</strong></div>` : ""}
      ${hasTransp ? `<div class="pp-comm-row"><span>Transporte</span><strong>${qs("sumTransporte").textContent}</strong></div>` : ""}
      ${hasMargem ? `<div class="pp-comm-row"><span>Margem aplicada</span><strong>${qs("sumMargem").textContent}</strong></div>` : ""}
    </div>
    <div class="pp-total-row">
      <div class="pp-total-box">
        <span>Valor total (sem IVA)</span>
        <strong>${qs("sumVenda").textContent}</strong>
      </div>
      <div class="pp-m2-box">
        <span>Preço por m²</span>
        <strong>${qs("sumPrecoM2").textContent}</strong>
      </div>
    </div>
`;
}

/* ============================================================
   TOAST
   ============================================================ */
function showToast(msg) {
  let t = qs("stkToast");
  if (!t) {
    t = document.createElement("div");
    t.id = "stkToast";
    t.className = "stk-toast";
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add("stk-toast--show");
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove("stk-toast--show"), 2600);
}

/* ============================================================
   SIDEBAR — navegação ativa ao scroll
   ============================================================ */
function updateActiveNav() {
  const steps = ["step-cliente", "step-sistema", "step-comercial", "step-materiais", "step-resumo"];
  let activeIdx = 0;
  steps.forEach((id, i) => {
    const el = qs(id);
    if (el && el.getBoundingClientRect().top <= 120) activeIdx = i;
  });
  document.querySelectorAll(".nav-item").forEach((item, i) =>
    item.classList.toggle("active", i === activeIdx));
}

/* ============================================================
   INIT
   ============================================================ */
const debouncedCalc = debounce(calculate, 80);

document.querySelectorAll("input").forEach((el) => el.addEventListener("input", debouncedCalc));
document.querySelectorAll("select").forEach((el) => el.addEventListener("change", calculate));
document.querySelectorAll(".sys-btn").forEach((btn) =>
  btn.addEventListener("click", () => loadSystem(btn.dataset.system)));
qs("resetBtn")?.addEventListener("click", resetAll);

let _rafPending = false;
window.addEventListener("scroll", () => {
  if (!_rafPending) {
    _rafPending = true;
    requestAnimationFrame(() => { updateActiveNav(); _rafPending = false; });
  }
}, { passive: true });

qs("isodurSistema")?.addEventListener("change", updateIsodurFields);
qs("becorkProd")?.addEventListener("change", updateBecorkFields);
qs("adhereCor")?.addEventListener("change", () => { updateAdhereFields(); calculate(); });
qs("reabConsolidacao")?.addEventListener("change", () => { updateReabilitaFields(); calculate(); });
qs("reabReboco")?.addEventListener("change", () => { updateReabilitaFields(); calculate(); });
qs("isovitPanel")?.addEventListener("change", () => { updateIsovitFields(); calculate(); });

qs("addToComparatorBtn")?.addEventListener("click", addToComparison);
qs("comparatorSection")?.addEventListener("click", (e) => {
  const btn = e.target.closest(".cmp-del");
  if (!btn) return;
  const id = Number(btn.dataset.id);
  const idx = comparisons.findIndex(c => c.id === id);
  if (idx !== -1) { comparisons.splice(idx, 1); renderComparator(); }
});

window.addEventListener("beforeprint", buildPrintProposal);

updateIsodurFields();
updateBecorkFields();
updateIsovitFields();
updateAdhereFields();
updateReabilitaFields();
loadSystem("microart");
